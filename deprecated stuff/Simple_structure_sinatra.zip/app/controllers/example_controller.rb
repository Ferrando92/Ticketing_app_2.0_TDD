# example_controller.rb
class ExampleController < ApplicationController
  get '/' do
    'Example!'
  end
end